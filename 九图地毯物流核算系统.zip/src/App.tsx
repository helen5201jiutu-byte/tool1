/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Calculator, 
  Package, 
  Truck, 
  Scale, 
  Box, 
  Info, 
  AlertTriangle, 
  CheckCircle2,
  ChevronRight,
  Maximize2
} from 'lucide-react';

type PackType = 'roll' | 'flat';
type Factor = 5000 | 6000;

export default function App() {
  const [vFactor, setVFactor] = useState<Factor>(5000);
  const [packType, setPackType] = useState<PackType>('roll');
  const [dim1, setDim1] = useState<string>('');
  const [dim2, setDim2] = useState<string>('');
  const [dim3, setDim3] = useState<string>('');
  const [singleWeight, setSingleWeight] = useState<string>('');
  const [qty, setQty] = useState<string>('1');
  const [showResult, setShowResult] = useState(false);

  const results = useMemo(() => {
    const d1 = parseFloat(dim1) || 0;
    const d2 = parseFloat(dim2) || 0;
    const d3 = parseFloat(dim3) || 0;
    const sW = parseFloat(singleWeight) || 0;
    const q = parseInt(qty) || 0;

    let unitCbm = 0;
    if (packType === 'roll') {
      // Roll: L * D * D
      unitCbm = (d1 * d2 * d2) / 1000000;
    } else {
      // Flat: L * W * H
      unitCbm = (d1 * d2 * d3) / 1000000;
    }

    const totalCbm = unitCbm * q;
    const totalActualWeight = sW * q;
    const totalVolWeight = (totalCbm * 1000000) / vFactor;
    const finalWeight = Math.max(totalActualWeight, totalVolWeight);
    
    // Container loading (10% loss)
    const unitWithLoss = unitCbm * 1.1;
    const calcBox = (cap: number) => unitWithLoss > 0 ? Math.floor(cap / unitWithLoss) : 0;

    return {
      totalCbm,
      totalActualWeight,
      totalVolWeight,
      finalWeight,
      isVolumetric: totalVolWeight > totalActualWeight,
      num20: calcBox(28),
      num40: calcBox(58),
      num40hq: calcBox(68)
    };
  }, [vFactor, packType, dim1, dim2, dim3, singleWeight, qty]);

  const handleCalculate = () => {
    if (!dim1 || !dim2 || (!dim3 && packType === 'flat') || !singleWeight) {
      alert('请填写完整的尺寸和重量信息');
      return;
    }
    setShowResult(true);
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900 font-sans p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <header className="mb-8 text-center">
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 text-xs font-bold uppercase tracking-wider mb-4 border border-emerald-100"
          >
            <Truck size={14} />
            Global Logistics System
          </motion.div>
          <h1 className="text-3xl md:text-4xl font-black tracking-tight text-slate-900 mb-2">
            九图地毯 <span className="text-emerald-600">物流核算</span>
          </h1>
          <p className="text-slate-500 max-w-lg mx-auto text-sm md:text-base">
            专业的地毯装箱与全球物流计费核算工具，为您的全球贸易提供精准数据支持。
          </p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Input Section */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:col-span-5 space-y-6"
          >
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 space-y-6">
              <div className="flex items-center gap-2 pb-4 border-bottom border-slate-100">
                <div className="p-2 bg-slate-100 rounded-lg">
                  <Calculator size={20} className="text-slate-600" />
                </div>
                <h2 className="font-bold text-slate-800">核算参数</h2>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">运输方式 (计费系数)</label>
                  <select 
                    value={vFactor}
                    onChange={(e) => setVFactor(Number(e.target.value) as Factor)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all outline-none appearance-none cursor-pointer"
                  >
                    <option value={5000}>国际快递 (1:5000)</option>
                    <option value={6000}>空运/海运拼箱 (1:6000)</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">打包方式</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button 
                      onClick={() => setPackType('roll')}
                      className={`flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-sm font-medium transition-all border ${packType === 'roll' ? 'bg-emerald-600 text-white border-emerald-600' : 'bg-white text-slate-600 border-slate-200 hover:border-emerald-200'}`}
                    >
                      <Package size={16} />
                      卷装地毯
                    </button>
                    <button 
                      onClick={() => setPackType('flat')}
                      className={`flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-sm font-medium transition-all border ${packType === 'flat' ? 'bg-emerald-600 text-white border-emerald-600' : 'bg-white text-slate-600 border-slate-200 hover:border-emerald-200'}`}
                    >
                      <Box size={16} />
                      折叠/箱装
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                      {packType === 'roll' ? '卷轴长度 (cm)' : '长度 (cm)'}
                    </label>
                    <input 
                      type="number" 
                      value={dim1}
                      onChange={(e) => setDim1(e.target.value)}
                      placeholder="L"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all outline-none"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                      {packType === 'roll' ? '直径 (cm)' : '宽度 (cm)'}
                    </label>
                    <input 
                      type="number" 
                      value={dim2}
                      onChange={(e) => setDim2(e.target.value)}
                      placeholder={packType === 'roll' ? 'D' : 'W'}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all outline-none"
                    />
                  </div>
                </div>

                {packType === 'flat' && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="space-y-2"
                  >
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">高度 (cm)</label>
                    <input 
                      type="number" 
                      value={dim3}
                      onChange={(e) => setDim3(e.target.value)}
                      placeholder="H"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all outline-none"
                    />
                  </motion.div>
                )}

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">单件实重 (kg)</label>
                    <input 
                      type="number" 
                      value={singleWeight}
                      onChange={(e) => setSingleWeight(e.target.value)}
                      placeholder="Weight"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all outline-none"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">总件数</label>
                    <input 
                      type="number" 
                      value={qty}
                      onChange={(e) => setQty(e.target.value)}
                      placeholder="Qty"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all outline-none"
                    />
                  </div>
                </div>
              </div>

              <button 
                onClick={handleCalculate}
                className="w-full bg-slate-900 text-white font-bold py-4 rounded-xl hover:bg-slate-800 active:scale-[0.98] transition-all flex items-center justify-center gap-2 shadow-lg shadow-slate-200"
              >
                执行物流核算
                <ChevronRight size={18} />
              </button>
            </div>
          </motion.div>

          {/* Result Section */}
          <div className="lg:col-span-7">
            <AnimatePresence mode="wait">
              {!showResult ? (
                <motion.div 
                  key="empty"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="h-full min-h-[400px] flex flex-col items-center justify-center bg-white rounded-2xl border-2 border-dashed border-slate-200 p-8 text-center"
                >
                  <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mb-4">
                    <Info className="text-slate-300" size={32} />
                  </div>
                  <h3 className="text-lg font-bold text-slate-400">等待核算</h3>
                  <p className="text-slate-400 text-sm max-w-xs mt-2">
                    请在左侧输入地毯的规格、重量及运输方式，系统将为您实时计算物流数据。
                  </p>
                </motion.div>
              ) : (
                <motion.div 
                  key="result"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="space-y-6"
                >
                  {/* Main Weight Card */}
                  <div className="bg-slate-900 rounded-2xl p-8 text-white relative overflow-hidden shadow-xl">
                    <div className="absolute top-0 right-0 p-8 opacity-10">
                      <Scale size={120} />
                    </div>
                    
                    <div className="relative z-10">
                      <div className="flex items-center gap-2 text-emerald-400 mb-2">
                        {results.isVolumetric ? <AlertTriangle size={16} /> : <CheckCircle2 size={16} />}
                        <span className="text-xs font-bold uppercase tracking-widest">计费重量 (Chargeable Weight)</span>
                      </div>
                      
                      <div className="flex items-baseline gap-2">
                        <span className="text-6xl font-black tracking-tighter">{results.finalWeight.toFixed(2)}</span>
                        <span className="text-2xl font-bold text-slate-400">kg</span>
                      </div>

                      <div className="mt-6 flex items-center gap-4">
                        <div className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${results.isVolumetric ? 'bg-orange-500/20 text-orange-400 border border-orange-500/30' : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'}`}>
                          {results.isVolumetric ? '⚠️ 泡货计费 (Volumetric)' : '✅ 实重计费 (Actual)'}
                        </div>
                        <div className="text-slate-400 text-xs">
                          基于系数 1:{vFactor} 计算
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Stats Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                      <div className="text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1">总体积</div>
                      <div className="text-xl font-black text-slate-800">{results.totalCbm.toFixed(3)} <span className="text-xs font-normal text-slate-400 uppercase">CBM</span></div>
                    </div>
                    <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                      <div className="text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1">总实重</div>
                      <div className="text-xl font-black text-slate-800">{results.totalActualWeight.toFixed(2)} <span className="text-xs font-normal text-slate-400 uppercase">KG</span></div>
                    </div>
                    <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                      <div className="text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1">体积重</div>
                      <div className="text-xl font-black text-slate-800">{results.totalVolWeight.toFixed(2)} <span className="text-xs font-normal text-slate-400 uppercase">KG</span></div>
                    </div>
                  </div>

                  {/* Container Loading */}
                  <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                    <div className="bg-slate-50 px-6 py-4 border-b border-slate-100 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Maximize2 size={18} className="text-emerald-600" />
                        <h3 className="font-bold text-slate-800">整柜装载量预估</h3>
                      </div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase bg-white px-2 py-1 rounded border border-slate-200">扣除10%损耗</span>
                    </div>
                    
                    <div className="p-6">
                      <div className="grid grid-cols-3 gap-4">
                        <div className="text-center space-y-2">
                          <div className="text-[10px] font-bold text-slate-400 uppercase">20GP 小柜</div>
                          <div className="text-2xl font-black text-emerald-600">{results.num20} <span className="text-[10px] font-bold text-slate-400 uppercase">件</span></div>
                          <div className="w-full h-1 bg-slate-100 rounded-full overflow-hidden">
                            <div className="h-full bg-emerald-500 w-[40%]"></div>
                          </div>
                        </div>
                        <div className="text-center space-y-2 border-x border-slate-100 px-4">
                          <div className="text-[10px] font-bold text-slate-400 uppercase">40GP 大柜</div>
                          <div className="text-2xl font-black text-emerald-600">{results.num40} <span className="text-[10px] font-bold text-slate-400 uppercase">件</span></div>
                          <div className="w-full h-1 bg-slate-100 rounded-full overflow-hidden">
                            <div className="h-full bg-emerald-500 w-[70%]"></div>
                          </div>
                        </div>
                        <div className="text-center space-y-2">
                          <div className="text-[10px] font-bold text-slate-400 uppercase">40HQ 高柜</div>
                          <div className="text-2xl font-black text-emerald-600">{results.num40hq} <span className="text-[10px] font-bold text-slate-400 uppercase">件</span></div>
                          <div className="w-full h-1 bg-slate-100 rounded-full overflow-hidden">
                            <div className="h-full bg-emerald-500 w-full"></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 p-4 bg-blue-50 rounded-xl border border-blue-100">
                    <Info className="text-blue-500 shrink-0" size={18} />
                    <p className="text-xs text-blue-700 leading-relaxed">
                      <strong>说明：</strong> 计费重量取实重与体积重之较大值。装载量预估已考虑10%的装箱空隙损耗，实际装箱数可能因地毯软硬度及堆叠方式有所偏差。
                    </p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Footer */}
        <footer className="mt-12 pt-8 border-t border-slate-200 text-center text-slate-400 text-xs">
          <p>© 2026 九图地毯 (JIUTU) 全球物流核算系统 · 内部专用版本</p>
        </footer>
      </div>
    </div>
  );
}
